package com.loan.flows;

import org.bson.Document;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCursor;

public class FindAllLoan_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {

		MbOutputTerminal out = getOutputTerminal("out");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessage outMessage = new MbMessage(inMessage);
		MbMessage outLocalEnv = new MbMessage(inAssembly.getLocalEnvironment());
		MbMessage outExceptionList = new MbMessage(inAssembly.getExceptionList());
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outLocalEnv, outExceptionList, outMessage);
				
		try{
			DbConnection conn = new DbConnection();
			FindIterable<Document> doc = conn.getCollection(CollectionEnum.LOAN).find();
			MongoCursor<Document> iterator = doc.iterator();
			
			MbElement xml = outMessage.getRootElement().createElementAsLastChild(MbXMLNSC.PARSER_NAME);
			MbElement root =  xml.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "root", null);
		
			while(iterator.hasNext()){
				Document obj = iterator.next();
				MbElement loan = root.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "loan", null);
				for(String key : obj.keySet()){
					loan.createElementAsLastChild(MbXMLNSC.FIELD, key, obj.get(key).toString());
				}
			}
			
			conn.closeConnection();
	        
		}catch(Exception e){
			e.printStackTrace();
		}
		
		outMessage.finalizeMessage(MbMessage.FINALIZE_VALIDATE);

		try {
			// optionally copy message headers
			copyMessageHeaders(inMessage, outMessage);
			// ----------------------------------------------------------
			// Add user code below

			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			throw e;
		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		out.propagate(outAssembly);
	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) // stop before
																	// the last
																	// child
																	// (body)
		{
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}
}
